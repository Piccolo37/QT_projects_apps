#include "chartwindow3.h"
#include "ui_chartwindow3.h"
#include <QVBoxLayout>
#include <QtMath>
#include <QScrollArea>

chartwindow3::chartwindow3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chartwindow3)
{
    // --- 1. KONFIGURACJA SCROLL AREA ---
    QWidget *container = new QWidget();
    ui->setupUi(container);
    container->setMinimumSize(1396, 915);

    QScrollArea *scrollArea = new QScrollArea(this);
    scrollArea->setWidget(container);
    scrollArea->setWidgetResizable(true);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(scrollArea);

    this->resize(1200, 800);

    // --- 2. RĘCZNE PODŁĄCZENIE PRZYCISKÓW ---

    // Pomiary
    if(ui->Pomiar_start_chart3)
        connect(ui->Pomiar_start_chart3, &QPushButton::clicked, this, &chartwindow3::on_Pomiar_start_chart3_clicked);

    if(ui->Pomiar_stop_chart3)
        connect(ui->Pomiar_stop_chart3, &QPushButton::clicked, this, &chartwindow3::on_Pomiar_stop_chart3_clicked);

    if(ui->czysc_wykresy_chart3)
        connect(ui->czysc_wykresy_chart3, &QPushButton::clicked, this, &chartwindow3::on_czysc_wykresy_chart3_clicked);

    if(ui->Eksport_danych_do_pliku_chart3)
        connect(ui->Eksport_danych_do_pliku_chart3, &QPushButton::clicked, this, &chartwindow3::on_Eksport_danych_do_pliku_chart3_clicked);

    if(ui->Modul_pomiarowy_I_V_f_koniec_chart3)
        connect(ui->Modul_pomiarowy_I_V_f_koniec_chart3, &QPushButton::clicked, this, &chartwindow3::on_Modul_pomiarowy_I_V_f_koniec_chart3_clicked);

    // Zapis do JPG
    if(ui->Zapisz_wykres_chart3)
        connect(ui->Zapisz_wykres_chart3, &QPushButton::clicked, this, &chartwindow3::on_Zapisz_wykres_chart3_clicked);

    // Sterowanie Falownikiem
    if(ui->freq_send_3)
        connect(ui->freq_send_3, &QPushButton::clicked, this, &chartwindow3::on_freq_send_3_clicked);

    if(ui->obroty_start_3)
        connect(ui->obroty_start_3, &QPushButton::clicked, this, &chartwindow3::on_obroty_start_3_clicked);

    if(ui->obroty_stop_3)
        connect(ui->obroty_stop_3, &QPushButton::clicked, this, &chartwindow3::on_obroty_stop_3_clicked);

    // --- 3. INICJALIZACJA WYKRESU ---
    initCharts();

    // --- 4. LOGIKA UI FALOWNIKA ---
    if (ui->wartosc_f_3 && ui->falownik_f_value_zadana_3) {
        ui->wartosc_f_3->setRange(0, 5000);
        ui->wartosc_f_3->setValue(0);
        ui->wartosc_f_3->setNotchesVisible(true);
        ui->wartosc_f_3->setWrapping(false);

        ui->falownik_f_value_zadana_3->setText("0.00 Hz");

        connect(ui->wartosc_f_3, &QDial::valueChanged, this, [=](int value){
            double hz = value / 100.0;
            ui->falownik_f_value_zadana_3->setText(QString::number(hz, 'f', 2) + " Hz");
        });
    }

    // --- 5. SKALOWANIE ---
    if(ui->spinBox_X_chart3) ui->spinBox_X_chart3->setValue(10);
    if(ui->spinBox_StepX_chart3) ui->spinBox_StepX_chart3->setValue(1);
    if(ui->spinBox_Y_chart3) ui->spinBox_Y_chart3->setValue(20.0);
    if(ui->spinBox_StepY_chart3) ui->spinBox_StepY_chart3->setValue(2.0);

    void (QDoubleSpinBox::*sigD)(double) = &QDoubleSpinBox::valueChanged;
    void (QSpinBox::*sigI)(int) = &QSpinBox::valueChanged;

    if(ui->spinBox_Y_chart3) connect(ui->spinBox_Y_chart3, sigD, this, &chartwindow3::onSettingsChanged);
    if(ui->spinBox_StepY_chart3) connect(ui->spinBox_StepY_chart3, sigD, this, &chartwindow3::onSettingsChanged);
    if(ui->spinBox_X_chart3) connect(ui->spinBox_X_chart3, sigI, this, &chartwindow3::onSettingsChanged);
    if(ui->spinBox_StepX_chart3) connect(ui->spinBox_StepX_chart3, sigI, this, &chartwindow3::onSettingsChanged);

    onSettingsChanged();
}

chartwindow3::~chartwindow3()
{
    delete ui;
}

// === IMPLEMENTACJA BRAKUJĄCEJ FUNKCJI (ROZWIĄZANIE BŁĘDU LINKERA 1) ===
void chartwindow3::displayCycleTime(const QString &info)
{
    if (ui->falownik_cykl_pracy) {
        ui->falownik_cykl_pracy->setText(info);
    }
}

void chartwindow3::initCharts()
{
    if (ui->wykres_Vf_If->layout()) delete ui->wykres_Vf_If->layout();
    QVBoxLayout *layout = new QVBoxLayout(ui->wykres_Vf_If);
    layout->setContentsMargins(0,0,0,0);

    m_chart = new QChart();
    m_chart->setTitle("Przebiegi: Prąd (I), Napięcie (U), Częstotliwość (f)");
    m_chart->legend()->setVisible(true);
    m_chart->legend()->setAlignment(Qt::AlignBottom);

    m_axisX = new QValueAxis();
    m_axisX->setTitleText("Czas [s]");
    m_chart->addAxis(m_axisX, Qt::AlignBottom);

    // 1. PRĄD
    m_series_I = new QLineSeries(); m_series_I->setName("Prąd [A]");
    QPen penI(Qt::blue); penI.setWidth(2); m_series_I->setPen(penI);
    m_chart->addSeries(m_series_I);
    m_axisY_I = new QValueAxis(); m_axisY_I->setTitleText("I [A]");
    m_axisY_I->setLinePenColor(Qt::blue); m_axisY_I->setLabelsColor(Qt::blue);
    m_chart->addAxis(m_axisY_I, Qt::AlignLeft);
    m_series_I->attachAxis(m_axisX); m_series_I->attachAxis(m_axisY_I);

    // 2. NAPIĘCIE
    m_series_U = new QLineSeries(); m_series_U->setName("Napięcie [V]");
    QPen penU(Qt::red); penU.setWidth(2); m_series_U->setPen(penU);
    m_chart->addSeries(m_series_U);
    m_axisY_U = new QValueAxis(); m_axisY_U->setTitleText("U [V]");
    m_axisY_U->setLinePenColor(Qt::red); m_axisY_U->setLabelsColor(Qt::red);
    m_chart->addAxis(m_axisY_U, Qt::AlignRight);
    m_series_U->attachAxis(m_axisX); m_series_U->attachAxis(m_axisY_U);

    // 3. CZĘSTOTLIWOŚĆ
    m_series_F = new QLineSeries(); m_series_F->setName("Częstotliwość [Hz]");
    QPen penF(Qt::darkGreen); penF.setWidth(2); m_series_F->setPen(penF);
    m_chart->addSeries(m_series_F);
    m_axisY_F = new QValueAxis(); m_axisY_F->setTitleText("f [Hz]");
    m_axisY_F->setLinePenColor(Qt::darkGreen); m_axisY_F->setLabelsColor(Qt::darkGreen);
    m_chart->addAxis(m_axisY_F, Qt::AlignRight);
    m_series_F->attachAxis(m_axisX); m_series_F->attachAxis(m_axisY_F);

    m_chartView = new QChartView(m_chart);
    m_chartView->setRenderHint(QPainter::Antialiasing);
    layout->addWidget(m_chartView);
}

void chartwindow3::appendData(double t, double current, double voltage, double freq)
{
    m_series_I->append(t, current);
    m_series_U->append(t, voltage);
    m_series_F->append(t, freq);

    double windowSize = 10.0;
    if(ui->spinBox_X_chart3) windowSize = static_cast<double>(ui->spinBox_X_chart3->value());

    if (t > windowSize) {
        m_axisX->setRange(t - windowSize, t);
    } else {
        m_axisX->setRange(0, windowSize);
    }
    updateTicks();
}

void chartwindow3::onSettingsChanged()
{
    if(ui->spinBox_Y_chart3) m_axisY_I->setRange(0, ui->spinBox_Y_chart3->value());
    m_axisY_U->setRange(0, 600);
    m_axisY_F->setRange(0, 60);

    if(ui->spinBox_X_chart3) {
        double windowSize = static_cast<double>(ui->spinBox_X_chart3->value());
        if (m_series_I->count() > 0) {
            double lastTime = m_series_I->at(m_series_I->count() - 1).x();
            if (lastTime > windowSize) m_axisX->setRange(lastTime - windowSize, lastTime);
            else m_axisX->setRange(0, windowSize);
        } else {
            m_axisX->setRange(0, windowSize);
        }
    }
    updateTicks();
}

void chartwindow3::updateTicks()
{
    if(ui->spinBox_StepX_chart3) {
        double step = (double)ui->spinBox_StepX_chart3->value();
        double range = m_axisX->max() - m_axisX->min();
        if(step > 0.1) {
            int ticks = qRound(range / step) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisX->setTickCount(ticks);
        }
    }
    if(ui->spinBox_StepY_chart3) {
        double step = ui->spinBox_StepY_chart3->value();
        double range = m_axisY_I->max() - m_axisY_I->min();
        if(step > 0.01) {
            int ticks = qRound(range / step) + 1;
            m_axisY_I->setTickCount(ticks);
        }
    }
    m_axisY_U->setTickCount(7);
    m_axisY_F->setTickCount(7);
}

// --- SLOTY PRZYCISKÓW ---

void chartwindow3::on_Pomiar_start_chart3_clicked()
{
    m_series_I->clear();
    m_series_U->clear();
    m_series_F->clear();

    if(ui->spinBox_X_chart3) m_axisX->setRange(0, ui->spinBox_X_chart3->value());

    if(ui->falownik_cykl_pracy) ui->falownik_cykl_pracy->clear();

    emit startMeasurementRequested();
}

void chartwindow3::on_Pomiar_stop_chart3_clicked()
{
    emit stopMeasurementRequested();
}

void chartwindow3::on_czysc_wykresy_chart3_clicked()
{
    m_series_I->clear();
    m_series_U->clear();
    m_series_F->clear();
    if(ui->falownik_cykl_pracy) ui->falownik_cykl_pracy->clear();
    onSettingsChanged();
}

void chartwindow3::on_Eksport_danych_do_pliku_chart3_clicked()
{
    if (m_series_I->count() == 0) {
        QMessageBox::information(this, "Info", "Brak danych do zapisania.");
        return;
    }
    QString fileName = QFileDialog::getSaveFileName(this, "Zapisz", QDir::homePath() + "/pomiar_3parametry.csv", "CSV (*.csv)");
    if (fileName.isEmpty()) return;
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Błąd", "Nie można otworzyć pliku do zapisu.");
        return;
    }
    QTextStream out(&file);
    out << "Czas [s];Prad [A];Napiecie [V];Czestotliwosc [Hz]\n";
    for (int i = 0; i < m_series_I->count(); ++i) {
        QPointF pI = m_series_I->at(i);
        double uVal = (i < m_series_U->count()) ? m_series_U->at(i).y() : 0.0;
        double fVal = (i < m_series_F->count()) ? m_series_F->at(i).y() : 0.0;
        out << pI.x() << ";" << pI.y() << ";" << uVal << ";" << fVal << "\n";
    }
    file.close();
    QMessageBox::information(this, "Sukces", "Zapisano dane do pliku.");
}

void chartwindow3::on_Modul_pomiarowy_I_V_f_koniec_chart3_clicked()
{
    emit stopMeasurementRequested();
    this->close();
}

// === IMPLEMENTACJA BRAKUJĄCEJ FUNKCJI (ROZWIĄZANIE BŁĘDU LINKERA 2) ===
void chartwindow3::on_Zapisz_wykres_chart3_clicked()
{
    if (!m_chartView) {
        QMessageBox::warning(this, "Błąd", "Wykres nie został zainicjalizowany.");
        return;
    }
    QPixmap pixmap = m_chartView->grab();
    QString fileName = QFileDialog::getSaveFileName(this, "Zapisz obraz", QDir::homePath() + "/wykres.jpg", "JPG (*.jpg);;PNG (*.png)");
    if (fileName.isEmpty()) return;
    if (pixmap.save(fileName, nullptr, 100)) {
        QMessageBox::information(this, "Sukces", "Wykres zapisany.");
    } else {
        QMessageBox::warning(this, "Błąd", "Nie udało się zapisać pliku.");
    }
}

// --- STEROWANIE ---

void chartwindow3::on_freq_send_3_clicked()
{
    double freq = 0.0;
    if(ui->wartosc_f_3) freq = ui->wartosc_f_3->value() / 100.0;
    emit setInverterFrequency(freq);
}

void chartwindow3::on_obroty_start_3_clicked()
{
    emit startInverter();
}

void chartwindow3::on_obroty_stop_3_clicked()
{
    emit stopInverter();
}

void chartwindow3::closeEvent(QCloseEvent *event)
{
    emit stopMeasurementRequested();
    emit windowClosed();
    QWidget::closeEvent(event);
}
