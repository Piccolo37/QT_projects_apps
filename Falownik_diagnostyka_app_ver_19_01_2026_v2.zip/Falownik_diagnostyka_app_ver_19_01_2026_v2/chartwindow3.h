#ifndef CHARTWINDOW3_H
#define CHARTWINDOW3_H

#include <QWidget>
#include <QtCharts>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class chartwindow3;
}

class chartwindow3 : public QWidget
{
    Q_OBJECT

public:
    explicit chartwindow3(QWidget *parent = nullptr);
    ~chartwindow3();

    void appendData(double t, double current, double voltage, double freq);

    // --- SLOT ODBIERAJĄCY SYGNAŁ Z MAINWINDOW ---
public slots:
    void displayCycleTime(const QString &info);

signals:
    void startMeasurementRequested();
    void stopMeasurementRequested();
    void windowClosed();
    void setInverterFrequency(double freq);
    void startInverter();
    void stopInverter();

private slots:
    // Pomiary
    void on_Pomiar_start_chart3_clicked();
    void on_Pomiar_stop_chart3_clicked();
    void on_czysc_wykresy_chart3_clicked();
    void on_Eksport_danych_do_pliku_chart3_clicked();
    void on_Modul_pomiarowy_I_V_f_koniec_chart3_clicked();

    // Zapis grafiki (nazwa ujednolicona z UI)
    void on_Zapisz_wykres_chart3_clicked();

    // Sterowanie
    void on_freq_send_3_clicked();
    void on_obroty_start_3_clicked();
    void on_obroty_stop_3_clicked();

    void onSettingsChanged();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::chartwindow3 *ui;

    QChartView *m_chartView;
    QChart *m_chart;
    QValueAxis *m_axisX;

    QLineSeries *m_series_I;
    QLineSeries *m_series_U;
    QLineSeries *m_series_F;

    QValueAxis *m_axisY_I;
    QValueAxis *m_axisY_U;
    QValueAxis *m_axisY_F;

    void initCharts();
    void updateTicks();
};

#endif // CHARTWINDOW3_H
