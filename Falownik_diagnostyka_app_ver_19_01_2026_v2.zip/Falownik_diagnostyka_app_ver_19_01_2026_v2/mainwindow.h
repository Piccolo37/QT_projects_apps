#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QTimer>
#include <QElapsedTimer>
#include <QByteArray>
#include <QDateTime> // <--- NIEZBĘDNE DO OBSŁUGI CZASU RZECZYWISTEGO (Delta t)

class ChartWindow;
class chartwindow2;
class chartwindow3;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onRefreshPortsClicked();
    void onConnectClicked();
    void onDisconnectClicked();
    void onClearLogClicked();

    // Obsługa tabeli błędów
    void onClearErrorTableClicked();
    void onSaveErrorLogsClicked();

    void on_RESET_ERROR_STATUS_clicked();
    void onManualStatusBtnClicked();

    // Sloty wyboru falownika
    void onFal1Selected();
    void onFal2Selected();

    void onCrcCalcClicked();

    void updateFreqTarget(int value);
    void sendCmdFreq();
    void sendCmdStart();
    void sendCmdStop();

    // Otwieranie okien wykresów
    void onOpenChartModuleClicked();
    void onOpenChartModule2Clicked();
    void onOpenChartModule3Clicked();

    void onChartStartRequested();
    void onChartStopRequested();
    void onChartWindowClosed();

    void onPollTimeout();
    void onSerialReadyRead();

private:
    Ui::MainWindow *ui;
    QSerialPort m_serial;
    QTimer m_pollTimer;
    QByteArray m_rxBuffer;
    QElapsedTimer m_time; // Czas względny (od startu aplikacji)

    quint16 m_targetFreqRaw = 0;
    bool m_measuring = false;
    bool m_waitingForResponse = false;

    // Aktualny ID falownika
    quint8 m_currentSlaveId = 0x01;

    // --- ZMIENNE DO POMIARU CZASU CYKLU (Delta t) ---
    bool m_motorCycleActive = false; // Czy silnik aktualnie pracuje?
    QDateTime m_motorCycleStartTime; // Znacznik czasu startu (t0)

    ChartWindow *m_chartWindow = nullptr;
    chartwindow2 *m_chartWindow2 = nullptr;
    chartwindow3 *m_chartWindow3 = nullptr;

    void fillSerialUiDefaults();
    bool applyUiSerialSettings(QString &humanDesc, QString &err);
    void logCom(const QString &msg);

    void logErrorToTable(const QString &msg, bool isError);

    void sendWriteRequest(quint16 address, quint16 value);
    void sendReadStatusAndDataRequest();
    bool tryParseResponse(QByteArray &frame);
    quint16 obliczNoweCRC(const QByteArray &data);

    bool m_manualCheckRequested = false;
};

#endif // MAINWINDOW_H
