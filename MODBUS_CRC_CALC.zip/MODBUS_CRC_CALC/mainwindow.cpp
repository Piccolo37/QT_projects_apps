#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSerialPortInfo>
#include <QtMath>
#include <QStringList>

// =======================
//  Konstruktor / Destruktor
// =======================
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Placeholdery
    ui->lineEdit->setPlaceholderText("Np: 01 03 22 00 00 01");
    ui->lineEdit_2->setPlaceholderText("Np: 01 03 02 0B 2C BE A9");
    ui->lineEdit_4->setPlaceholderText("Np (HEX): 01 03 22 00 00 01 8E 72");
    ui->lineEdit_3->setPlaceholderText("opcjonalnie (nieużywane w parserze RTU)");

    // Wypełnij comboboxy (Baud/Data/Stop/Parity/Flow) + domyślne
    fillSerialUiDefaults();

    // Ręczne podpięcie przycisków COM (żeby nie wymuszać nazw on_pushButton_X_clicked)
    connect(ui->pushButton_6,  &QPushButton::clicked, this, &MainWindow::onRefreshPortsClicked);
    connect(ui->pushButton_8,  &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(ui->pushButton_10, &QPushButton::clicked, this, &MainWindow::onDisconnectClicked);
    connect(ui->pushButton_7,  &QPushButton::clicked, this, &MainWindow::onSendClicked);
    connect(ui->pushButton_9,  &QPushButton::clicked, this, &MainWindow::onClearLogClicked);

    // Timer polling 50ms
    m_pollTimer.setInterval(50);
    connect(&m_pollTimer, &QTimer::timeout, this, &MainWindow::onPollTimeout);

    // Odbiór danych z COM
    connect(&m_serial, &QSerialPort::readyRead, this, &MainWindow::onSerialReadyRead);

    // Porty na starcie
    onRefreshPortsClicked();
}

MainWindow::~MainWindow()
{
    if (m_pollTimer.isActive())
        m_pollTimer.stop();

    if (m_serial.isOpen())
        m_serial.close();

    delete ui;
}

// =======================
//  Logger COM/status -> textBrowser_5
// =======================
void MainWindow::logCom(const QString &msg)
{
    if (ui && ui->textBrowser_5)
        ui->textBrowser_5->append(msg);
}

// =======================
//  Wypełnianie comboboxów serial (Baud/Data/Stop/Parity/Flow)
// =======================
void MainWindow::fillSerialUiDefaults()
{
    // Baud Rate
    ui->comboBox_2->clear();
    const QList<qint32> baudRates = QSerialPortInfo::standardBaudRates();
    for (qint32 b : baudRates)
        ui->comboBox_2->addItem(QString::number(b), b);

    // Data Bits
    ui->comboBox_3->clear();
    ui->comboBox_3->addItem("5", int(QSerialPort::Data5));
    ui->comboBox_3->addItem("6", int(QSerialPort::Data6));
    ui->comboBox_3->addItem("7", int(QSerialPort::Data7));
    ui->comboBox_3->addItem("8", int(QSerialPort::Data8));

    // Stop Bits
    ui->comboBox_4->clear();
    ui->comboBox_4->addItem("1",   int(QSerialPort::OneStop));
    ui->comboBox_4->addItem("1.5", int(QSerialPort::OneAndHalfStop));
    ui->comboBox_4->addItem("2",   int(QSerialPort::TwoStop));

    // Parity
    ui->comboBox_5->clear();
    ui->comboBox_5->addItem("None",  int(QSerialPort::NoParity));
    ui->comboBox_5->addItem("Even",  int(QSerialPort::EvenParity));
    ui->comboBox_5->addItem("Odd",   int(QSerialPort::OddParity));
    ui->comboBox_5->addItem("Mark",  int(QSerialPort::MarkParity));
    ui->comboBox_5->addItem("Space", int(QSerialPort::SpaceParity));

    // Flow Control
    ui->comboBox_6->clear();
    ui->comboBox_6->addItem("None",     int(QSerialPort::NoFlowControl));
    ui->comboBox_6->addItem("Hardware", int(QSerialPort::HardwareControl));
    ui->comboBox_6->addItem("Software", int(QSerialPort::SoftwareControl));

    // Domyślne: 9600 8N1, No Flow
    const int idx9600 = ui->comboBox_2->findText("9600");
    if (idx9600 >= 0) ui->comboBox_2->setCurrentIndex(idx9600);

    const int idx8 = ui->comboBox_3->findText("8");
    if (idx8 >= 0) ui->comboBox_3->setCurrentIndex(idx8);

    const int idx1 = ui->comboBox_4->findText("1");
    if (idx1 >= 0) ui->comboBox_4->setCurrentIndex(idx1);

    const int idxNoneP = ui->comboBox_5->findText("None");
    if (idxNoneP >= 0) ui->comboBox_5->setCurrentIndex(idxNoneP);

    const int idxNoneF = ui->comboBox_6->findText("None");
    if (idxNoneF >= 0) ui->comboBox_6->setCurrentIndex(idxNoneF);
}

// =======================
//  REFRESH PORTS (pushButton_6)
// =======================
void MainWindow::refreshPortsList()
{
    ui->comboBox->clear();

    const auto ports = QSerialPortInfo::availablePorts();
    for (const auto &p : ports) {
        const QString nice =
            p.portName() + (p.description().isEmpty() ? "" : " (" + p.description() + ")");
        // itemData = czyste portName (bez opisu)
        ui->comboBox->addItem(nice, p.portName());
    }
}

void MainWindow::onRefreshPortsClicked()
{
    refreshPortsList();
    logCom("Odświeżono listę portów COM.");
}

QString MainWindow::selectedPortName() const
{
    // preferuj itemData (ustawione w refreshPortsList)
    const QVariant v = ui->comboBox->currentData();
    if (v.isValid() && !v.toString().trimmed().isEmpty())
        return v.toString().trimmed();

    // fallback: wytnij z "COM5 (opis)"
    const QString sel = ui->comboBox->currentText();
    return sel.section(' ', 0, 0).trimmed();
}

bool MainWindow::applyUiSerialSettings(QString &humanDesc, QString &err)
{
    err.clear();
    humanDesc.clear();

    // Port
    const QString portName = selectedPortName();
    if (portName.isEmpty()) {
        err = "Nie wybrano portu COM.";
        return false;
    }

    // Baud
    bool okB = false;
    const int baud = ui->comboBox_2->currentText().toInt(&okB);
    if (!okB || baud <= 0) {
        err = "Niepoprawny Baud Rate.";
        return false;
    }

    // Data bits
    const int db = ui->comboBox_3->currentData().toInt();
    if (db == 0) {
        err = "Niepoprawne Data Bits.";
        return false;
    }

    // Stop bits
    const int sb = ui->comboBox_4->currentData().toInt();
    if (sb == 0) {
        err = "Niepoprawne Stop Bits.";
        return false;
    }

    // Parity
    const int par = ui->comboBox_5->currentData().toInt();

    // Flow
    const int flow = ui->comboBox_6->currentData().toInt();

    m_serial.setPortName(portName);
    m_serial.setBaudRate(baud);
    m_serial.setDataBits(static_cast<QSerialPort::DataBits>(db));
    m_serial.setStopBits(static_cast<QSerialPort::StopBits>(sb));
    m_serial.setParity(static_cast<QSerialPort::Parity>(par));
    m_serial.setFlowControl(static_cast<QSerialPort::FlowControl>(flow));

    humanDesc = QString("%1, %2, DB=%3, SB=%4, Par=%5, Flow=%6")
                    .arg(portName)
                    .arg(baud)
                    .arg(ui->comboBox_3->currentText())
                    .arg(ui->comboBox_4->currentText())
                    .arg(ui->comboBox_5->currentText())
                    .arg(ui->comboBox_6->currentText());

    return true;
}

// =======================
//  CONNECT (pushButton_8)
// =======================
void MainWindow::onConnectClicked()
{
    if (m_serial.isOpen()) {
        logCom("Port już otwarty: " + m_serial.portName());
        return;
    }

    QString human, err;
    if (!applyUiSerialSettings(human, err)) {
        logCom("Błąd ustawień portu: " + err);
        return;
    }

    if (!m_serial.open(QIODevice::ReadWrite)) {
        logCom("Błąd: nie można otworzyć portu.");
        return;
    }

    m_serial.clear(QSerialPort::AllDirections);
    m_rxBuffer.clear();
    logCom("Połączono: " + human);
}

// =======================
//  DISCONNECT (pushButton_10)
// =======================
void MainWindow::onDisconnectClicked()
{
    if (m_pollTimer.isActive())
        m_pollTimer.stop();

    m_measuring = false;

    if (m_serial.isOpen()) {
        const QString p = m_serial.portName();
        m_serial.close();
        logCom("Rozłączono: " + p);
    } else {
        logCom("Port nie był otwarty.");
    }
}

// =======================
//  SEND (pushButton_7) – wysyłka z lineEdit_4
//  Domyślnie: próba parsowania HEX; jeśli nie wyjdzie -> ASCII
// =======================
void MainWindow::onSendClicked()
{
    if (!m_serial.isOpen()) {
        logCom("Send: port nie jest połączony.");
        return;
    }

    const QString txt = ui->lineEdit_4->text().trimmed();
    if (txt.isEmpty()) {
        logCom("Send: pusta wiadomość.");
        return;
    }

    QByteArray data;
    QString err;
    if (parseHexBytes(txt, data, err)) {
        m_serial.write(data);
        m_serial.flush();
        logCom("TX (HEX): " + bytesToHexSpaced(data));
        return;
    }

    // fallback ASCII
    data = txt.toUtf8();
    m_serial.write(data);
    m_serial.flush();
    logCom("TX (ASCII): " + txt);
}

// =======================
//  CLEAR (pushButton_9) – czyści log COM
// =======================
void MainWindow::onClearLogClicked()
{
    if (ui && ui->textBrowser_5)
        ui->textBrowser_5->clear();
}

// =======================
//  CRC16 Modbus RTU
// =======================
quint16 MainWindow::modbusCrc16(const QByteArray &data)
{
    quint16 crc = 0xFFFF;
    for (unsigned char ch : data) {
        crc ^= quint16(ch);
        for (int i = 0; i < 8; ++i) {
            crc = (crc & 1) ? ((crc >> 1) ^ 0xA001) : (crc >> 1);
        }
    }
    return crc;
}

// =======================
//  Parsowanie HEX -> bajty
// =======================
bool MainWindow::parseHexBytes(const QString &text, QByteArray &out, QString &err)
{
    out.clear();

    QString t = text.trimmed();
    if (t.isEmpty()) {
        err = "Puste pole wejściowe.";
        return false;
    }

    t.replace(",", " ");
    t.replace(";", " ");
    t.replace("\t", " ");
    t.replace("\n", " ");
    t.replace("\r", " ");

    const QStringList tokens = t.split(" ", Qt::SkipEmptyParts);
    for (QString tok : tokens) {
        tok = tok.trimmed();
        tok.remove("0x", Qt::CaseInsensitive);

        bool ok = false;
        int v = tok.toInt(&ok, 16);
        if (!ok || v < 0 || v > 0xFF) {
            err = QString("Niepoprawny bajt HEX: '%1'").arg(tok);
            return false;
        }
        out.append(char(v & 0xFF));
    }

    if (out.size() < 2) {
        err = "Za mało bajtów.";
        return false;
    }
    return true;
}

QString MainWindow::bytesToHexSpaced(const QByteArray &data)
{
    QString s;
    for (int i = 0; i < data.size(); ++i) {
        s += QString("%1").arg(quint8(data.at(i)), 2, 16, QLatin1Char('0')).toUpper();
        if (i + 1 < data.size()) s += " ";
    }
    return s;
}

// =======================
//  Dekodowanie 1 rejestru (RTU 0x03/0x04)
// =======================
bool MainWindow::decode1RegisterResponse(const QByteArray &frame,
                                         quint8 &addr, quint8 &func,
                                         quint16 &regValue,
                                         QString &err)
{
    addr = 0; func = 0; regValue = 0;
    err.clear();

    // addr func byteCount dataHi dataLo crcLo crcHi
    if (frame.size() < 7) {
        err = "Za krótka ramka odpowiedzi (dla 1 rejestru: >= 7 bajtów).";
        return false;
    }

    const QByteArray payload = frame.left(frame.size() - 2);
    const quint8 crcLoRx = quint8(frame.at(frame.size() - 2));
    const quint8 crcHiRx = quint8(frame.at(frame.size() - 1));
    const quint16 crcRx = (quint16(crcHiRx) << 8) | quint16(crcLoRx);

    const quint16 crcCalc = modbusCrc16(payload);
    if (crcCalc != crcRx) {
        err = QString("CRC niezgodne. RX=0x%1, CALC=0x%2")
        .arg(crcRx, 4, 16, QLatin1Char('0'))
            .arg(crcCalc, 4, 16, QLatin1Char('0'));
        return false;
    }

    addr = quint8(frame.at(0));
    func = quint8(frame.at(1));

    // Exception response
    if (func & 0x80) {
        const quint8 exCode = quint8(frame.at(2));
        err = QString("Modbus exception. Addr=%1 Func=0x%2 Code=0x%3")
                  .arg(addr)
                  .arg(func, 2, 16, QLatin1Char('0'))
                  .arg(exCode, 2, 16, QLatin1Char('0'));
        return false;
    }

    if (func != 0x03 && func != 0x04) {
        err = QString("Nieobsługiwana funkcja: 0x%1 (oczekuję 0x03/0x04).")
                  .arg(func, 2, 16, QLatin1Char('0'));
        return false;
    }

    const quint8 byteCount = quint8(frame.at(2));
    if (byteCount != 2) {
        err = QString("byteCount=%1 (dla 1 rejestru oczekuję 2).").arg(byteCount);
        return false;
    }

    const quint8 dataHi = quint8(frame.at(3));
    const quint8 dataLo = quint8(frame.at(4));
    regValue = (quint16(dataHi) << 8) | quint16(dataLo);

    return true;
}

double MainWindow::applyDecimals(quint16 raw) const
{
    return double(raw) / qPow(10.0, double(m_currentDecimals));
}

// =======================
//  OBLICZ_CRC (pushButton)
// =======================
void MainWindow::on_pushButton_clicked()
{
    QByteArray msg;
    QString err;

    if (!parseHexBytes(ui->lineEdit->text(), msg, err)) {
        ui->textBrowser->setText("Błąd parsowania: " + err);
        return;
    }

    QByteArray payload = msg;
    bool inputHadValidCrc = false;

    if (msg.size() >= 6) {
        QByteArray candidatePayload = msg.left(msg.size() - 2);

        quint16 crcCandidate = modbusCrc16(candidatePayload);
        quint8 crcLoCalc = quint8(crcCandidate & 0xFF);
        quint8 crcHiCalc = quint8((crcCandidate >> 8) & 0xFF);

        quint8 crcLoIn = quint8(msg.at(msg.size() - 2));
        quint8 crcHiIn = quint8(msg.at(msg.size() - 1));

        if (crcLoCalc == crcLoIn && crcHiCalc == crcHiIn) {
            payload = candidatePayload;
            inputHadValidCrc = true;
        }
    }

    quint16 crc = modbusCrc16(payload);
    quint8 crcLo = quint8(crc & 0xFF);
    quint8 crcHi = quint8((crc >> 8) & 0xFF);

    QByteArray full = payload;
    full.append(char(crcLo));
    full.append(char(crcHi));

    QString out;
    out += "Wejście: " + bytesToHexSpaced(msg) + "\n";
    out += QString("Wejście zawiera poprawne CRC: %1\n").arg(inputHadValidCrc ? "TAK" : "NIE");
    out += "CRC = 0x" + QString("%1").arg(crc, 4, 16, QLatin1Char('0')).toUpper() + "\n";
    out += "CRC bytes (LSB first) = "
           + QString("%1 %2").arg(crcLo, 2, 16, QLatin1Char('0'))
                 .arg(crcHi, 2, 16, QLatin1Char('0')).toUpper() + "\n";
    out += "Ramka do wysłania: " + bytesToHexSpaced(full);

    ui->textBrowser->setText(out);
}

// =======================
//  PODAJ WARTOŚĆ PRĄDU (pushButton_2) – z wklejonej ramki
// =======================
void MainWindow::on_pushButton_2_clicked()
{
    QByteArray frame;
    QString err;

    if (!parseHexBytes(ui->lineEdit_2->text(), frame, err)) {
        ui->textBrowser_2->setText("Błąd parsowania: " + err);
        return;
    }

    quint8 addr = 0, func = 0;
    quint16 reg = 0;

    if (!decode1RegisterResponse(frame, addr, func, reg, err)) {
        ui->textBrowser_2->setText("Błąd dekodowania: " + err);
        return;
    }

    QString out;
    out += "Ramka: " + bytesToHexSpaced(frame) + "\n";
    out += QString("ADDR=%1 FUNC=0x%2 REG=0x%3 (%4)\n")
               .arg(addr)
               .arg(func, 2, 16, QLatin1Char('0')).toUpper()
               .arg(reg, 4, 16, QLatin1Char('0')).toUpper()
               .arg(reg);

    if (reg <= 6) {
        m_currentDecimals = int(reg);
        out += "Ustawiono decimal places = " + QString::number(m_currentDecimals);
        ui->textBrowser_2->setText(out);
        return;
    }

    const double currentA = applyDecimals(reg);
    out += "Decimal places = " + QString::number(m_currentDecimals) + "\n";
    out += "Prąd = " + QString::number(currentA, 'f', m_currentDecimals) + " A";
    ui->textBrowser_2->setText(out);
}

// =======================
//  START pomiaru (pushButton_3)
// =======================
void MainWindow::on_pushButton_3_clicked()
{
    if (!m_serial.isOpen()) {
        logCom("Błąd: port nie jest połączony. Kliknij Connect.");
        return;
    }

    m_samplesA.clear();
    m_rxBuffer.clear();
    m_measuring = true;

    ui->textBrowser_2->clear();
    ui->textBrowser_3->clear();
    ui->textBrowser_4->clear();

    logCom("START pomiaru: polling 50 ms.");
    m_pollTimer.start();
}

// =======================
//  STOP pomiaru (pushButton_4)
// =======================
void MainWindow::on_pushButton_4_clicked()
{
    m_pollTimer.stop();
    m_measuring = false;

    logCom("STOP pomiaru.");
    updateMinMaxFields();
}

// =======================
//  Budowa requestu z CRC z ui->lineEdit
// =======================
QByteArray MainWindow::buildRequestWithCrcFromLineEdit(QString &err) const
{
    QByteArray msg;
    if (!parseHexBytes(ui->lineEdit->text(), msg, err)) {
        return {};
    }

    if (msg.size() < 4) {
        err = "Za krótka ramka zapytania.";
        return {};
    }

    // jeśli user wkleił już CRC i jest poprawne -> zostaw
    if (msg.size() >= 6) {
        const QByteArray payload = msg.left(msg.size() - 2);
        const quint16 crc = modbusCrc16(payload);
        const quint8 crcLo = quint8(crc & 0xFF);
        const quint8 crcHi = quint8((crc >> 8) & 0xFF);

        const quint8 inLo = quint8(msg.at(msg.size() - 2));
        const quint8 inHi = quint8(msg.at(msg.size() - 1));

        if (inLo == crcLo && inHi == crcHi) {
            return msg;
        }

        // jeśli CRC nie pasuje, potraktuj jak payload bez CRC
        msg = payload;
    }

    const quint16 crc = modbusCrc16(msg);
    msg.append(char(crc & 0xFF));
    msg.append(char((crc >> 8) & 0xFF));
    return msg;
}

// =======================
//  Polling: wysyłka co 50ms
// =======================
void MainWindow::onPollTimeout()
{
    if (!m_measuring || !m_serial.isOpen())
        return;

    QString err;
    const QByteArray req = buildRequestWithCrcFromLineEdit(err);
    if (req.isEmpty()) {
        ui->textBrowser_2->append("Błąd ramki zapytania: " + err);
        return;
    }

    m_serial.write(req);
    m_serial.flush();
}

// =======================
//  RTU parser z resynchronizacją (CRC)
// =======================
bool MainWindow::tryExtractAndValidateOneRtuFrame(QByteArray &frame, QString &err)
{
    frame.clear();
    err.clear();

    while (m_rxBuffer.size() >= 5) {
        if (m_rxBuffer.size() < 2)
            return false;

        const quint8 func = quint8(m_rxBuffer.at(1));

        int expectedLen = 0;
        if (func & 0x80) {
            expectedLen = 5; // exception: addr func|0x80 code crcLo crcHi
        } else {
            if (m_rxBuffer.size() < 3)
                return false;
            const quint8 byteCount = quint8(m_rxBuffer.at(2));
            expectedLen = 3 + int(byteCount) + 2;
        }

        if (expectedLen <= 0) {
            m_rxBuffer.remove(0, 1);
            continue;
        }

        if (m_rxBuffer.size() < expectedLen) {
            return false; // czekaj na resztę
        }

        const QByteArray candidate = m_rxBuffer.left(expectedLen);

        const QByteArray payload = candidate.left(candidate.size() - 2);
        const quint8 rxLo = quint8(candidate.at(candidate.size() - 2));
        const quint8 rxHi = quint8(candidate.at(candidate.size() - 1));
        const quint16 rxCrc = (quint16(rxHi) << 8) | quint16(rxLo);

        const quint16 calc = modbusCrc16(payload);

        if (calc == rxCrc) {
            frame = candidate;
            m_rxBuffer.remove(0, expectedLen);
            return true;
        }

        // CRC nie pasuje -> resync (usuń 1 bajt)
        m_rxBuffer.remove(0, 1);
    }

    return false;
}

// =======================
//  Odbiór z portu
// =======================
void MainWindow::onSerialReadyRead()
{
    m_rxBuffer.append(m_serial.readAll());

    while (true) {
        QByteArray frame;
        QString perr;
        if (!tryExtractAndValidateOneRtuFrame(frame, perr)) {
            break;
        }

        quint8 addr = 0, func = 0;
        quint16 reg = 0;
        QString derr;

        if (!decode1RegisterResponse(frame, addr, func, reg, derr)) {
            ui->textBrowser_2->append("Błąd dekodowania: " + derr + " | " + bytesToHexSpaced(frame));
            continue;
        }

        const double currentA = applyDecimals(reg);
        m_samplesA.push_back(currentA);

        ui->textBrowser_2->append(
            QString("I=%1 A | N=%2 | frame=%3")
                .arg(QString::number(currentA, 'f', m_currentDecimals))
                .arg(m_samplesA.size())
                .arg(bytesToHexSpaced(frame))
            );
    }
}

// =======================
//  MAX/MIN po STOP
// =======================
void MainWindow::updateMinMaxFields()
{
    if (m_samplesA.isEmpty()) {
        ui->textBrowser_3->setText("brak danych");
        ui->textBrowser_4->setText("brak danych");
        return;
    }

    double maxV = m_samplesA.first();
    for (double v : m_samplesA)
        if (v > maxV) maxV = v;

    bool foundMin = false;
    double minV = 0.0;

    for (double v : m_samplesA) {
        if (v > m_minThresholdA) {
            if (!foundMin) { minV = v; foundMin = true; }
            else if (v < minV) { minV = v; }
        }
    }

    ui->textBrowser_3->setText(QString::number(maxV, 'f', m_currentDecimals));
    if (foundMin)
        ui->textBrowser_4->setText(QString::number(minV, 'f', m_currentDecimals));
    else
        ui->textBrowser_4->setText(QString("brak > %1 A").arg(m_minThresholdA));
}
