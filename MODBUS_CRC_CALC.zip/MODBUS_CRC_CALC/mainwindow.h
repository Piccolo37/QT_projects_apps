#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#pragma once

#include <QMainWindow>
#include <QSerialPort>
#include <QTimer>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Auto-sloty z UI (Twoje istniejące)
    void on_pushButton_clicked();      // OBLICZ_CRC
    void on_pushButton_2_clicked();    // PODAJ WARTOŚĆ PRĄDU (z wklejonej ramki)
    void on_pushButton_3_clicked();    // POMIAR PRĄDU START
    void on_pushButton_4_clicked();    // POMIAR PRĄDU STOP

    // COM (podpinane ręcznie, nie auto-slot)
    void onRefreshPortsClicked();      // pushButton_6
    void onConnectClicked();           // pushButton_8
    void onDisconnectClicked();        // pushButton_10
    void onSendClicked();              // pushButton_7
    void onClearLogClicked();          // pushButton_9

    // Polling / RX
    void onPollTimeout();
    void onSerialReadyRead();

private:
    Ui::MainWindow *ui;

    // --- Modbus helpers ---
    static quint16 modbusCrc16(const QByteArray &data);
    static bool parseHexBytes(const QString &text, QByteArray &out, QString &err);
    static QString bytesToHexSpaced(const QByteArray &data);

    static bool decode1RegisterResponse(const QByteArray &frame,
                                        quint8 &addr, quint8 &func,
                                        quint16 &regValue,
                                        QString &err);

    double applyDecimals(quint16 raw) const;

    // --- RS-485 / Modbus ---
    QSerialPort m_serial;
    QTimer m_pollTimer;
    QByteArray m_rxBuffer;

    // --- Pomiary ---
    QVector<double> m_samplesA;
    bool m_measuring = false;

    // Skale/filtry
    int m_currentDecimals = 2;          // XX.XX A
    double m_minThresholdA = 10.0;      // min tylko dla > 10A

    // --- COM/UI logika ---
    void fillSerialUiDefaults();
    void refreshPortsList();
    QString selectedPortName() const;
    bool applyUiSerialSettings(QString &humanDesc, QString &err);

    // --- Modbus / pomiar ---
    QByteArray buildRequestWithCrcFromLineEdit(QString &err) const;
    bool tryExtractAndValidateOneRtuFrame(QByteArray &frame, QString &err);
    void updateMinMaxFields();

    // --- log COM/status -> textBrowser_5 ---
    void logCom(const QString &msg);
};








#endif // MAINWINDOW_H
