#include "chartwindow.h"
#include "ui_chartwindow.h"
#include <QVBoxLayout>
#include <QtMath>

ChartWindow::ChartWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChartWindow)
{
    ui->setupUi(this);

    initChartInsidePlaceholder();

    // --- 1. KONFIGURACJA POKRĘTŁA I SUWAKÓW ---
    // Ustawienie zakresu pokrętła (0 - 50.00 Hz)
    if(ui->wartosc_f_2) {
        ui->wartosc_f_2->setRange(0, 5000);
        ui->wartosc_f_2->setNotchesVisible(true);
        ui->wartosc_f_2->setValue(0);
        connect(ui->wartosc_f_2, &QDial::valueChanged, this, &ChartWindow::onDialValueChanged);
    }

    // Reset wyświetlacza
    if(ui->falownik_f_value_zadana_2) {
        ui->falownik_f_value_zadana_2->setText("0.00 Hz");
    }

    // --- 2. PODPIĘCIE PRZYCISKÓW STEROWANIA (TO JEST ZAIMPLEMENTOWANE) ---

    // FREQ_SEND (freq_send_2)
    if(ui->freq_send_2)
        connect(ui->freq_send_2, &QPushButton::clicked, this, &ChartWindow::onBtnFreqSendClicked);

    // OBROTY_START (obroty_start_2)
    if(ui->obroty_start_2)
        connect(ui->obroty_start_2, &QPushButton::clicked, this, &ChartWindow::onBtnStartClicked);

    // OBROTY_STOP (obroty_stop_2)
    if(ui->obroty_stop_2)
        connect(ui->obroty_stop_2, &QPushButton::clicked, this, &ChartWindow::onBtnStopClicked);


    // --- 3. KONFIGURACJA WYKRESÓW ---
    if(ui->spinBox_Y) ui->spinBox_Y->setValue(20.0);
    if(ui->spinBox_StepY) ui->spinBox_StepY->setValue(2.0);
    if(ui->spinBox_X) ui->spinBox_X->setValue(10);
    if(ui->spinBox_StepX) ui->spinBox_StepX->setValue(1);

    void (QDoubleSpinBox::*sigD)(double) = &QDoubleSpinBox::valueChanged;
    void (QSpinBox::*sigI)(int) = &QSpinBox::valueChanged;

    if(ui->spinBox_Y) connect(ui->spinBox_Y, sigD, this, &ChartWindow::onSettingsChanged);
    if(ui->spinBox_StepY) connect(ui->spinBox_StepY, sigD, this, &ChartWindow::onSettingsChanged);
    if(ui->spinBox_X) connect(ui->spinBox_X, sigI, this, &ChartWindow::onSettingsChanged);
    if(ui->spinBox_StepX) connect(ui->spinBox_StepX, sigI, this, &ChartWindow::onSettingsChanged);

    if(ui->pushButton_3) ui->pushButton_3->setEnabled(false); // Eksport off

    onSettingsChanged();
}

ChartWindow::~ChartWindow()
{
    delete ui;
}

// --- SLOTY STEROWANIA (ZAIMPLEMENTOWANE) ---

void ChartWindow::onDialValueChanged(int value)
{
    m_localTargetFreq = value;
    double freqHz = value / 100.0;
    if(ui->falownik_f_value_zadana_2) {
        ui->falownik_f_value_zadana_2->setText(QString::number(freqHz, 'f', 2) + " Hz");
    }
}

void ChartWindow::onBtnFreqSendClicked()
{
    // Emitujemy sygnał do MainWindow
    emit inverterFreqWriteRequested(m_localTargetFreq);
}

void ChartWindow::onBtnStartClicked()
{
    emit inverterStartRequested();
}

void ChartWindow::onBtnStopClicked()
{
    emit inverterStopRequested();
}

// --- LOGIKA WYKRESU ---

void ChartWindow::initChartInsidePlaceholder() {
    m_series = new QLineSeries();
    m_chart = new QChart();
    m_chart->addSeries(m_series);
    m_chart->legend()->hide();

    m_axisX = new QValueAxis();
    m_axisX->setTitleText("Czas [s]");
    m_chart->addAxis(m_axisX, Qt::AlignBottom);
    m_series->attachAxis(m_axisX);

    m_axisY = new QValueAxis();
    m_axisY->setTitleText("Prąd [A]");
    m_chart->addAxis(m_axisY, Qt::AlignLeft);
    m_series->attachAxis(m_axisY);

    m_chartView = new QChartView(m_chart);
    m_chartView->setRenderHint(QPainter::Antialiasing);

    if (ui->chartContainer) {
        if (ui->chartContainer->layout()) delete ui->chartContainer->layout();
        QVBoxLayout *layout = new QVBoxLayout(ui->chartContainer);
        layout->addWidget(m_chartView);
        ui->chartContainer->setLayout(layout);
    }
}

void ChartWindow::appendDataPoint(double time, double current) {
    m_series->append(time, current);

    if(current > m_maxCurrent) m_maxCurrent = current;
    if(current < m_minCurrent) m_minCurrent = current;

    if(ui->textBrowser_3) ui->textBrowser_3->setText(QString::number(m_maxCurrent, 'f', 2) + " A");
    if(ui->textBrowser_4) ui->textBrowser_4->setText(QString::number(m_minCurrent, 'f', 2) + " A");

    double windowSize = (ui->spinBox_X) ? (double)ui->spinBox_X->value() : 10.0;
    if (time > windowSize) m_axisX->setRange(time - windowSize, time);
    else m_axisX->setRange(0, windowSize);

    updateTicks();
}

void ChartWindow::on_pushButton_clicked() { // Start Pomiaru
    m_series->clear();
    m_maxCurrent = 0.0; m_minCurrent = 999.0;

    if(ui->textBrowser_3) ui->textBrowser_3->clear();
    if(ui->textBrowser_4) ui->textBrowser_4->clear();

    if(ui->pushButton_3) ui->pushButton_3->setEnabled(false);

    emit startMeasurementRequested();
}

void ChartWindow::on_pushButton_2_clicked() { // Stop Pomiaru
    emit stopMeasurementRequested();
    if(ui->pushButton_3 && m_series->count() > 0) ui->pushButton_3->setEnabled(true);
}

void ChartWindow::on_btnClose_clicked() {
    emit stopMeasurementRequested();
    this->close();
}

void ChartWindow::on_pushButton_3_clicked() { // Eksport
    if (m_series->count() == 0) return;
    QString fileName = QFileDialog::getSaveFileName(this, "Zapisz", QDir::homePath(), "CSV (*.csv)");
    if (fileName.isEmpty()) return;
    QFile file(fileName);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << "Czas;Prad\n";
        for (const QPointF &p : m_series->points()) out << p.x() << ";" << p.y() << "\n";
    }
}

void ChartWindow::on_btnClear_clicked() {
    m_series->clear();
    m_maxCurrent = 0.0; m_minCurrent = 999.0;
    if(ui->textBrowser_3) ui->textBrowser_3->clear();
    if(ui->textBrowser_4) ui->textBrowser_4->clear();
}

void ChartWindow::onSettingsChanged() {
    if(ui->spinBox_Y) m_axisY->setRange(0, ui->spinBox_Y->value());
    updateTicks();
}

// --- TO BYŁO PUSTE W TWOIM KODZIE - UZUPEŁNIONE ---
void ChartWindow::updateTicks() {
    // Skalowanie siatki Y (Prąd)
    if(ui->spinBox_StepY) {
        double stepY = ui->spinBox_StepY->value();
        double rangeY = m_axisY->max() - m_axisY->min();
        if (stepY > 0.01) {
            int ticks = qRound(rangeY / stepY) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisY->setTickCount(ticks);
        }
    }
    // Skalowanie siatki X (Czas)
    if(ui->spinBox_StepX && ui->spinBox_X) {
        int stepX = ui->spinBox_StepX->value();
        double rangeX = m_axisX->max() - m_axisX->min();
        if (stepX > 0) {
            int ticks = qRound(rangeX / (double)stepX) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisX->setTickCount(ticks);
        }
    }
}

void ChartWindow::closeEvent(QCloseEvent *event) {
    emit stopMeasurementRequested();
    emit windowClosed();
    QWidget::closeEvent(event);
}
