#ifndef CHARTWINDOW_H
#define CHARTWINDOW_H

#include <QWidget>
#include <QtCharts>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QDateTime>

namespace Ui {
class ChartWindow;
}

class ChartWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ChartWindow(QWidget *parent = nullptr);
    ~ChartWindow();

    void appendDataPoint(double time, double current);

signals:
    // Istniejące sygnały pomiarowe
    void startMeasurementRequested();
    void stopMeasurementRequested();
    void windowClosed();

    // --- NOWE SYGNAŁY STEROWANIA FALOWNIKIEM ---
    // ChartWindow mówi: "Hej MainWindow, wyślij te rozkazy!"
    void inverterStartRequested();
    void inverterStopRequested();
    void inverterFreqWriteRequested(int rawValue); // Przesyła wartość 0-5000

private slots:
    // Obsługa przycisków pomiarowych (stare)
    void on_pushButton_clicked();   // START POMIARU
    void on_pushButton_2_clicked(); // STOP POMIARU
    void on_pushButton_3_clicked(); // EKSPORT
    void on_btnClear_clicked();     // CZYŚĆ
    void on_btnClose_clicked();     // ZAMKNIJ

    // --- NOWE SLOTY DO OBSŁUGI UI FALOWNIKA W CHARTWINDOW ---
    void onDialValueChanged(int value); // Obsługa pokrętła
    void onBtnFreqSendClicked();        // Przycisk FREQ_SEND
    void onBtnStartClicked();           // Przycisk START OBR.
    void onBtnStopClicked();            // Przycisk STOP OBR.

    void onSettingsChanged();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::ChartWindow *ui;

    QChartView *m_chartView;
    QChart *m_chart;
    QLineSeries *m_series;
    QValueAxis *m_axisX;
    QValueAxis *m_axisY;

    double m_maxCurrent = 0.0;
    double m_minCurrent = 999.0;

    // Zmienna przechowująca nastawę z pokrętła w tym oknie
    int m_localTargetFreq = 0;

    void initChartInsidePlaceholder();
    void updateTicks();
};

#endif // CHARTWINDOW_H
