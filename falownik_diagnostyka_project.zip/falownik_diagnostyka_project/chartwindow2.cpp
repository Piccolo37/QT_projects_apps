#include "chartwindow2.h"
#include "ui_chartwindow2.h"
#include <QVBoxLayout>
#include <QtMath>
#include <QScrollArea>

chartwindow2::chartwindow2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chartwindow2)
{
    // --- 1. KONFIGURACJA SCROLL AREA ---
    QWidget *container = new QWidget();
    ui->setupUi(container);

    container->setMinimumSize(1477, 1310);

    QScrollArea *scrollArea = new QScrollArea(this);
    scrollArea->setWidget(container);
    scrollArea->setWidgetResizable(true);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(scrollArea);

    this->resize(1200, 800);

    // --- 2. NAPRAWA PRZYCISKÓW (RĘCZNE PODŁĄCZENIE) ---
    // A. Przyciski FALOWNIKA
    if (ui->freq_send_3)
        connect(ui->freq_send_3, &QPushButton::clicked, this, &chartwindow2::on_freq_send_3_clicked);
    if (ui->obroty_start_3)
        connect(ui->obroty_start_3, &QPushButton::clicked, this, &chartwindow2::on_obroty_start_3_clicked);
    if (ui->obroty_stop_3)
        connect(ui->obroty_stop_3, &QPushButton::clicked, this, &chartwindow2::on_obroty_stop_3_clicked);

    // B. Przyciski POMIAROWE
    if (ui->Pomiar_start_chart2)
        connect(ui->Pomiar_start_chart2, &QPushButton::clicked, this, &chartwindow2::on_Pomiar_start_chart2_clicked);
    if (ui->Pomiar_stop_chart2)
        connect(ui->Pomiar_stop_chart2, &QPushButton::clicked, this, &chartwindow2::on_Pomiar_stop_chart2_clicked);
    if (ui->czysc_wykresy_chart2)
        connect(ui->czysc_wykresy_chart2, &QPushButton::clicked, this, &chartwindow2::on_czysc_wykresy_chart2_clicked);
    if (ui->Eksport_danych_do_pliku_chart2)
        connect(ui->Eksport_danych_do_pliku_chart2, &QPushButton::clicked, this, &chartwindow2::on_Eksport_danych_do_pliku_chart2_clicked);
    if (ui->Modul_pomiarowy_I_V_koniec_chart2)
        connect(ui->Modul_pomiarowy_I_V_koniec_chart2, &QPushButton::clicked, this, &chartwindow2::on_Modul_pomiarowy_I_V_koniec_chart2_clicked);

    // --- 3. INICJALIZACJA WYKRESÓW ---
    initCharts();

    // --- 4. LOGIKA FALOWNIKA (DOMYŚLNY WYGLĄD) ---

    if (ui->wartosc_f_3 && ui->falownik_f_value_zadana_3) {
        // A. Konfiguracja pokrętła (QDial)
        ui->wartosc_f_3->setRange(0, 6000); // 0.00 - 60.00 Hz
        ui->wartosc_f_3->setValue(0);

        // Zostawiamy tylko notch (kreski), bo to funkcjonalne
        ui->wartosc_f_3->setNotchesVisible(true);
        ui->wartosc_f_3->setWrapping(false);

        // USUNIĘTO WSZELKIE setStyleSheet - wygląd systemowy

        // B. Konfiguracja wyświetlacza (QTextBrowser)
        // USUNIĘTO HTML i STYLE - zwykły tekst
        ui->falownik_f_value_zadana_3->setText("0.00 Hz");

        // Połączenie: Zmiana pokrętła -> Aktualizacja pola tekstowego (zwykły tekst)
        connect(ui->wartosc_f_3, &QDial::valueChanged, this, [=](int value){
            double hz = value / 100.0;
            // Używamy prostego setText
            ui->falownik_f_value_zadana_3->setText(QString::number(hz, 'f', 2) + " Hz");
        });
    }

    // --- 5. WARTOŚCI DOMYŚLNE ---
    if(ui->spinBox_X_chart2) ui->spinBox_X_chart2->setValue(10);
    if(ui->spinBox_StepX_chart2) ui->spinBox_StepX_chart2->setValue(1);
    if(ui->spinBox_Y_chart2) ui->spinBox_Y_chart2->setValue(20.0);
    if(ui->spinBox_StepY_chart2) ui->spinBox_StepY_chart2->setValue(2.0);
    if(ui->spinBox_Max_Napiecie_Y_chart2) ui->spinBox_Max_Napiecie_Y_chart2->setValue(400.0);
    if(ui->spinBox_Napiecie_StepY_chart2) ui->spinBox_Napiecie_StepY_chart2->setValue(50.0);

    if(ui->spinBox_Max_Czestotliwosc_X_chart2) ui->spinBox_Max_Czestotliwosc_X_chart2->setEnabled(false);
    if(ui->spinBox_Czestotliwosc_StepX_chart2) ui->spinBox_Czestotliwosc_StepX_chart2->setEnabled(false);

    // --- 6. PODPIĘCIE SYGNAŁÓW ZMIANY USTAWIEŃ ---
    void (QDoubleSpinBox::*sigD)(double) = &QDoubleSpinBox::valueChanged;
    void (QSpinBox::*sigI)(int) = &QSpinBox::valueChanged;

    connect(ui->spinBox_Y_chart2, sigD, this, &chartwindow2::onSettingsChanged);
    connect(ui->spinBox_StepY_chart2, sigD, this, &chartwindow2::onSettingsChanged);
    connect(ui->spinBox_X_chart2, sigI, this, &chartwindow2::onSettingsChanged);
    connect(ui->spinBox_StepX_chart2, sigI, this, &chartwindow2::onSettingsChanged);
    connect(ui->spinBox_Max_Napiecie_Y_chart2, sigD, this, &chartwindow2::onSettingsChanged);
    connect(ui->spinBox_Napiecie_StepY_chart2, sigD, this, &chartwindow2::onSettingsChanged);

    onSettingsChanged();
}

chartwindow2::~chartwindow2()
{
    delete ui;
}

void chartwindow2::initCharts()
{
    // === WYKRES 1: PRĄD ===
    m_series_I = new QLineSeries();
    m_series_I->setName("Prąd [A]");

    m_chart_I = new QChart();
    m_chart_I->addSeries(m_series_I);
    m_chart_I->legend()->hide();
    m_chart_I->setTitle("Przebieg Prądu (I)");

    m_axisX_I = new QValueAxis();
    m_axisX_I->setTitleText("Czas [s]");
    m_chart_I->addAxis(m_axisX_I, Qt::AlignBottom);
    m_series_I->attachAxis(m_axisX_I);

    m_axisY_I = new QValueAxis();
    m_axisY_I->setTitleText("Prąd [A]");
    m_chart_I->addAxis(m_axisY_I, Qt::AlignLeft);
    m_series_I->attachAxis(m_axisY_I);

    m_chartView_I = new QChartView(m_chart_I);
    m_chartView_I->setRenderHint(QPainter::Antialiasing);

    if (ui->wykres_prad) {
        if (ui->wykres_prad->layout()) delete ui->wykres_prad->layout();
        QVBoxLayout *layout = new QVBoxLayout(ui->wykres_prad);
        layout->setContentsMargins(0,0,0,0);
        layout->addWidget(m_chartView_I);
        ui->wykres_prad->setLayout(layout);
    }

    // === WYKRES 2: NAPIĘCIE ===
    m_series_U = new QLineSeries();
    m_series_U->setName("Napięcie [V]");
    QPen pen = m_series_U->pen();
    pen.setColor(Qt::red);
    m_series_U->setPen(pen);

    m_chart_U = new QChart();
    m_chart_U->addSeries(m_series_U);
    m_chart_U->legend()->hide();
    m_chart_U->setTitle("Przebieg Napięcia (U)");

    m_axisX_U = new QValueAxis();
    m_axisX_U->setTitleText("Czas [s]");
    m_chart_U->addAxis(m_axisX_U, Qt::AlignBottom);
    m_series_U->attachAxis(m_axisX_U);

    m_axisY_U = new QValueAxis();
    m_axisY_U->setTitleText("Napięcie [V]");
    m_chart_U->addAxis(m_axisY_U, Qt::AlignLeft);
    m_series_U->attachAxis(m_axisY_U);

    m_chartView_U = new QChartView(m_chart_U);
    m_chartView_U->setRenderHint(QPainter::Antialiasing);

    if (ui->wykres_napiecie) {
        if (ui->wykres_napiecie->layout()) delete ui->wykres_napiecie->layout();
        QVBoxLayout *layout = new QVBoxLayout(ui->wykres_napiecie);
        layout->setContentsMargins(0,0,0,0);
        layout->addWidget(m_chartView_U);
        ui->wykres_napiecie->setLayout(layout);
    }
}

void chartwindow2::appendData(double t, double current, double voltage, double freq)
{
    Q_UNUSED(freq);
    m_series_I->append(t, current);
    m_series_U->append(t, voltage);

    double windowSize = 10.0;
    if(ui->spinBox_X_chart2) windowSize = static_cast<double>(ui->spinBox_X_chart2->value());

    if (t > windowSize) {
        m_axisX_I->setRange(t - windowSize, t);
        m_axisX_U->setRange(t - windowSize, t);
    } else {
        m_axisX_I->setRange(0, windowSize);
        m_axisX_U->setRange(0, windowSize);
    }
    updateTicks();
}

void chartwindow2::onSettingsChanged()
{
    if(ui->spinBox_Y_chart2) m_axisY_I->setRange(0, ui->spinBox_Y_chart2->value());
    if(ui->spinBox_Max_Napiecie_Y_chart2) m_axisY_U->setRange(0, ui->spinBox_Max_Napiecie_Y_chart2->value());

    if(m_series_I->count() == 0 && ui->spinBox_X_chart2) {
        double maxT = ui->spinBox_X_chart2->value();
        m_axisX_I->setRange(0, maxT);
        m_axisX_U->setRange(0, maxT);
    }
    updateTicks();
}

void chartwindow2::updateTicks()
{
    if(ui->spinBox_StepY_chart2) {
        double step = ui->spinBox_StepY_chart2->value();
        double range = m_axisY_I->max() - m_axisY_I->min();
        if(step > 0.01) {
            int ticks = qRound(range / step) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisY_I->setTickCount(ticks);
        }
    }
    if(ui->spinBox_Napiecie_StepY_chart2) {
        double step = ui->spinBox_Napiecie_StepY_chart2->value();
        double range = m_axisY_U->max() - m_axisY_U->min();
        if(step > 0.1) {
            int ticks = qRound(range / step) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisY_U->setTickCount(ticks);
        }
    }
    if(ui->spinBox_StepX_chart2) {
        double step = (double)ui->spinBox_StepX_chart2->value();
        double range = m_axisX_I->max() - m_axisX_I->min();
        if(step > 0.1) {
            int ticks = qRound(range / step) + 1;
            if(ticks < 2) ticks = 2; if(ticks > 50) ticks = 50;
            m_axisX_I->setTickCount(ticks);
            m_axisX_U->setTickCount(ticks);
        }
    }
}

// --- SLOTY PRZYCISKÓW ---

void chartwindow2::on_Pomiar_start_chart2_clicked()
{
    m_series_I->clear();
    m_series_U->clear();
    if(ui->spinBox_X_chart2) {
        double maxT = ui->spinBox_X_chart2->value();
        m_axisX_I->setRange(0, maxT);
        m_axisX_U->setRange(0, maxT);
    }
    emit startMeasurementRequested();
}

void chartwindow2::on_Pomiar_stop_chart2_clicked()
{
    emit stopMeasurementRequested();
}

void chartwindow2::on_czysc_wykresy_chart2_clicked()
{
    m_series_I->clear();
    m_series_U->clear();
    onSettingsChanged();
}

void chartwindow2::on_Modul_pomiarowy_I_V_koniec_chart2_clicked()
{
    emit stopMeasurementRequested();
    this->close();
}

void chartwindow2::on_Eksport_danych_do_pliku_chart2_clicked()
{
    if (m_series_I->count() == 0) return;
    QString fileName = QFileDialog::getSaveFileName(this, "Zapisz", QDir::homePath() + "/pomiar.csv", "CSV (*.csv)");
    if (fileName.isEmpty()) return;
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) return;
    QTextStream out(&file);
    out << "Czas [s];Prad [A];Napiecie [V]\n";
    for (int i = 0; i < m_series_I->count(); ++i) {
        QPointF pI = m_series_I->at(i);
        if(i < m_series_U->count()) {
            QPointF pU = m_series_U->at(i);
            out << pI.x() << ";" << pI.y() << ";" << pU.y() << "\n";
        }
    }
    file.close();
    QMessageBox::information(this, "Sukces", "Zapisano dane do pliku.");
}

// --- SLOTY FALOWNIKA (Nazwy zgodne z UI: _3) ---

void chartwindow2::on_freq_send_3_clicked()
{
    double freq = 0.0;
    if(ui->wartosc_f_3) {
        freq = ui->wartosc_f_3->value() / 100.0;
    }
    qDebug() << "Wysyłanie częstotliwości:" << freq;
    emit setInverterFrequency(freq);
}

void chartwindow2::on_obroty_start_3_clicked()
{
    qDebug() << "Start falownika";
    emit startInverter();
}

void chartwindow2::on_obroty_stop_3_clicked()
{
    qDebug() << "Stop falownika";
    emit stopInverter();
}

void chartwindow2::closeEvent(QCloseEvent *event)
{
    emit stopMeasurementRequested();
    emit windowClosed();
    QWidget::closeEvent(event);
}
