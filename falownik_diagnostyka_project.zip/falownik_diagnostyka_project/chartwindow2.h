#ifndef CHARTWINDOW2_H
#define CHARTWINDOW2_H

#include <QWidget>
#include <QtCharts>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class chartwindow2;
}

class chartwindow2 : public QWidget
{
    Q_OBJECT

public:
    explicit chartwindow2(QWidget *parent = nullptr);
    ~chartwindow2();

    void appendData(double t, double current, double voltage, double freq);

signals:
    // Sygnały sterujące
    void startMeasurementRequested();
    void stopMeasurementRequested();
    void windowClosed();
    void setInverterFrequency(double freq);
    void startInverter();
    void stopInverter();

private slots:
    // Stare przyciski (bez zmian w nazwach w UI)
    void on_Pomiar_start_chart2_clicked();
    void on_Pomiar_stop_chart2_clicked();
    void on_czysc_wykresy_chart2_clicked();
    void on_Eksport_danych_do_pliku_chart2_clicked();
    void on_Modul_pomiarowy_I_V_koniec_chart2_clicked();

    // --- NOWE NAZWY SLOTÓW (Dopasowane do UI) ---
    void on_freq_send_3_clicked();      // Było: on_btn_Freq_Send_clicked
    void on_obroty_start_3_clicked();   // Było: on_btn_Obroty_Start_clicked
    void on_obroty_stop_3_clicked();    // Było: on_btn_Obroty_Stop_clicked

    void onSettingsChanged();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::chartwindow2 *ui;

    QChartView *m_chartView_I;
    QChart *m_chart_I;
    QLineSeries *m_series_I;
    QValueAxis *m_axisX_I;
    QValueAxis *m_axisY_I;

    QChartView *m_chartView_U;
    QChart *m_chart_U;
    QLineSeries *m_series_U;
    QValueAxis *m_axisX_U;
    QValueAxis *m_axisY_U;

    void initCharts();
    void updateTicks();
};

#endif // CHARTWINDOW2_H
