#include "mainwindow.h"
#include <QApplication>
#include <QPalette>
#include <QColor>

static void forceWhiteTheme(QApplication &app)
{
    // Najpewniejsze wymuszenie jasnego wyglądu na Windows
    app.setStyle("windowsvista");

    // Jeśli gdzieś wcześniej ładowałeś QSS (ciemny), to go zdejmij
    app.setStyleSheet("");

    QPalette p;

    // Tła
    p.setColor(QPalette::Window, Qt::white);
    p.setColor(QPalette::Base, Qt::white);
    p.setColor(QPalette::Button, Qt::white);
    p.setColor(QPalette::AlternateBase, Qt::white);

    // Teksty
    p.setColor(QPalette::WindowText, Qt::black);
    p.setColor(QPalette::Text, Qt::black);
    p.setColor(QPalette::ButtonText, Qt::black);

    // Tooltipy
    p.setColor(QPalette::ToolTipBase, Qt::white);
    p.setColor(QPalette::ToolTipText, Qt::black);

    // Zaznaczenia
    p.setColor(QPalette::Highlight, QColor(0, 120, 215));
    p.setColor(QPalette::HighlightedText, Qt::white);

    app.setPalette(p);
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // MUSI być przed utworzeniem okna
    forceWhiteTheme(a);

    MainWindow w;
    w.show();

    return a.exec();
}
