#include "mainwindow.h"
#include "ui_mainwindow.h"

// --- BIBLIOTEKI QT ---
#include <QSerialPortInfo>
#include <QDebug>
#include <QDateTime>
#include <QTimer>
#include <QElapsedTimer>
#include <QtGlobal>

// --- OKNA WYKRESÓW ---
#include "chartwindow.h"
#include "chartwindow2.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // --- 1. SYGNAŁY STANDARDOWE ---
    connect(ui->pushButton_6, &QPushButton::clicked, this, &MainWindow::onRefreshPortsClicked);
    connect(ui->pushButton_8, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(ui->pushButton_10,&QPushButton::clicked, this, &MainWindow::onDisconnectClicked);
    connect(ui->pushButton_9, &QPushButton::clicked, this, &MainWindow::onClearLogClicked);

    // --- 2. WYKRESY ---
    connect(ui->pushButton_5, &QPushButton::clicked, this, &MainWindow::onOpenChartModuleClicked);

    if(ui->pushButton_11) {
        connect(ui->pushButton_11, &QPushButton::clicked, this, &MainWindow::onOpenChartModule2Clicked);
    }

    // --- 3. STEROWANIE ---
    if(ui->wartosc_f) connect(ui->wartosc_f, &QDial::valueChanged, this, &MainWindow::updateFreqTarget);
    if(ui->freq_send) connect(ui->freq_send, &QPushButton::clicked, this, &MainWindow::sendCmdFreq);
    if(ui->obroty_start) connect(ui->obroty_start, &QPushButton::clicked, this, &MainWindow::sendCmdStart);
    if(ui->obroty_stop) connect(ui->obroty_stop, &QPushButton::clicked, this, &MainWindow::sendCmdStop);

    // =========================================================================
    // POPRAWKA: PEWNE PODPIĘCIE PRZYCISKU STATUSU
    // Używamy nowej nazwy funkcji onManualStatusBtnClicked
    // =========================================================================
    if(ui->FALOWNIK_CHECK_STATUS) {
        connect(ui->FALOWNIK_CHECK_STATUS, &QPushButton::clicked, this, &MainWindow::onManualStatusBtnClicked);
    }

    if(ui->RESET_ERROR_STATUS) {
        connect(ui->RESET_ERROR_STATUS, &QPushButton::clicked, this, &MainWindow::on_RESET_ERROR_STATUS_clicked);
    }

    // --- 4. UI INIT ---
    if(ui->wartosc_f) {
        ui->wartosc_f->setRange(0, 5000);
        ui->wartosc_f->setNotchesVisible(true);
        ui->wartosc_f->setValue(0);
    }

    if(ui->falownik_f_value_zadana)
        ui->falownik_f_value_zadana->setText("0.00 Hz");

    // --- 5. TIMER I PORT ---
    m_pollTimer.setInterval(50);
    connect(&m_pollTimer, &QTimer::timeout, this, &MainWindow::onPollTimeout);
    connect(&m_serial, &QSerialPort::readyRead, this, &MainWindow::onSerialReadyRead);

    fillSerialUiDefaults();
    onRefreshPortsClicked();
}

MainWindow::~MainWindow() {
    if(m_serial.isOpen()) m_serial.close();
    if(m_chartWindow) delete m_chartWindow;
    if(m_chartWindow2) delete m_chartWindow2;
    delete ui;
}

// ==========================================
// STEROWANIE
// ==========================================

void MainWindow::updateFreqTarget(int value)
{
    m_targetFreqRaw = static_cast<quint16>(value);
    double freqHz = value / 100.0;
    if(ui->falownik_f_value_zadana) {
        ui->falownik_f_value_zadana->setText(QString::number(freqHz, 'f', 2) + " Hz");
    }
}

void MainWindow::sendCmdFreq()
{
    // Kliknięcie tutaj NIE MA WPŁYWU na manualny status (izolacja)
    sendWriteRequest(0x2001, m_targetFreqRaw);
    logCom(QString(">> ZAPIS FREQ: %1 Hz").arg(m_targetFreqRaw/100.0));
}

void MainWindow::sendCmdStart()
{
    sendWriteRequest(0x2000, 0x0012);
    logCom(">> START");
}

void MainWindow::sendCmdStop()
{
    sendWriteRequest(0x2000, 0x0001);
    logCom(">> STOP");
}

void MainWindow::on_RESET_ERROR_STATUS_clicked()
{
    // Kliknięcie RESETU kasuje ewentualne zawieszone żądanie manualne
    m_manualCheckRequested = false;

    if (!m_serial.isOpen()) {
        logCom("Port zamknięty!");
        return;
    }
    logCom("<b>>> RESET BŁĘDU (0x0008)...</b>");
    sendWriteRequest(0x2000, 0x0008);
}

// --- GŁÓWNA FUNKCJA SPRAWDZANIA STATUSU ---
void MainWindow::onManualStatusBtnClicked()
{
    // Debug w konsoli, aby potwierdzić działanie przycisku
    qDebug() << "PRZYCISK CHECK STATUS KLIKNIĘTY!";

    if (!m_serial.isOpen()) {
        logCom("Błąd: Port nieotwarty!");
        return;
    }

    logCom("<b>>> Manualne sprawdzenie statusu...</b>");

    // 1. Ustawiamy flagę - chcemy szczegółowy raport z odpowiedzi!
    m_manualCheckRequested = true;

    // 2. Czyścimy bufor, żeby nie odczytać starych śmieci
    m_rxBuffer.clear();

    // 3. Wymuszamy wysłanie (zdejmujemy blokadę czekania)
    m_waitingForResponse = false;

    // 4. Wysyłamy zapytanie
    sendReadStatusAndDataRequest();
}

void MainWindow::sendWriteRequest(quint16 address, quint16 value)
{
    if(!m_serial.isOpen()) {
        logCom("Błąd: Port nieotwarty!");
        return;
    }
    QByteArray req;
    req.append((char)0x01);
    req.append((char)0x06);
    req.append((char)((address >> 8) & 0xFF));
    req.append((char)(address & 0xFF));
    req.append((char)((value >> 8) & 0xFF));
    req.append((char)(value & 0xFF));

    quint16 crc = obliczNoweCRC(req);
    req.append((char)(crc & 0xFF));
    req.append((char)((crc >> 8) & 0xFF));

    m_serial.write(req);
}

// ==========================================
// OKNA WYKRESÓW
// ==========================================

void MainWindow::onOpenChartModuleClicked()
{
    if (!m_chartWindow) {
        m_chartWindow = new ChartWindow();
        connect(m_chartWindow, &ChartWindow::startMeasurementRequested, this, &MainWindow::onChartStartRequested);
        connect(m_chartWindow, &ChartWindow::stopMeasurementRequested, this, &MainWindow::onChartStopRequested);
        connect(m_chartWindow, &ChartWindow::windowClosed, this, &MainWindow::onChartWindowClosed);

        connect(m_chartWindow, &ChartWindow::inverterStartRequested, this, &MainWindow::sendCmdStart);
        connect(m_chartWindow, &ChartWindow::inverterStopRequested, this, &MainWindow::sendCmdStop);
        connect(m_chartWindow, &ChartWindow::inverterFreqWriteRequested, this, [this](int rawVal){
            this->sendWriteRequest(0x2001, (quint16)rawVal);
            this->logCom(QString(">> (Chart) FREQ: %1 Hz").arg(rawVal/100.0));
        });
    }
    m_chartWindow->show();
}

void MainWindow::onOpenChartModule2Clicked()
{
    if (!m_chartWindow2) {
        m_chartWindow2 = new chartwindow2();

        connect(m_chartWindow2, &chartwindow2::startMeasurementRequested, this, &MainWindow::onChartStartRequested);
        connect(m_chartWindow2, &chartwindow2::stopMeasurementRequested, this, &MainWindow::onChartStopRequested);
        connect(m_chartWindow2, &chartwindow2::windowClosed, this, &MainWindow::onChartWindowClosed);

        connect(m_chartWindow2, &chartwindow2::startInverter, this, &MainWindow::sendCmdStart);
        connect(m_chartWindow2, &chartwindow2::stopInverter, this, &MainWindow::sendCmdStop);

        connect(m_chartWindow2, &chartwindow2::setInverterFrequency, this, [this](double freq){
            quint16 rawVal = static_cast<quint16>(freq * 100);
            this->sendWriteRequest(0x2001, rawVal);
            this->logCom(QString(">> (Chart2) FREQ: %1 Hz").arg(freq, 0, 'f', 2));
        });
    }
    m_chartWindow2->show();
}

// ==========================================
// POMIARY
// ==========================================

void MainWindow::onChartStartRequested()
{
    // Start pomiarów kasuje flagę manualną, żeby nie mieszać logów
    m_manualCheckRequested = false;

    if(!m_serial.isOpen()) {
        logCom("Błąd: Port zamknięty!");
        return;
    }
    m_measuring = true;
    m_waitingForResponse = false;
    m_time.restart();

    if (!m_pollTimer.isActive()) m_pollTimer.start();

    logCom(">> START Pomiary (Automatyczne odpytywanie)");
}

void MainWindow::onChartStopRequested()
{
    m_measuring = false;
    m_pollTimer.stop();
    logCom(">> STOP Pomiary");
}

void MainWindow::onChartWindowClosed()
{
    onChartStopRequested();
}

void MainWindow::onPollTimeout() {
    sendReadStatusAndDataRequest();
}

void MainWindow::sendReadStatusAndDataRequest() {
    if(m_waitingForResponse) return;

    QByteArray req;
    req.append((char)0x01); // ID
    req.append((char)0x03); // Read
    req.append((char)0x21); req.append((char)0x00); // Adres 2100H
    req.append((char)0x00); req.append((char)0x07); // Ilość 7

    quint16 crc = obliczNoweCRC(req);
    req.append((char)(crc & 0xFF)); req.append((char)((crc >> 8) & 0xFF));

    m_waitingForResponse = true;
    m_serial.write(req);
}

// --- ODBIÓR DANYCH ---
void MainWindow::onSerialReadyRead() {
    QByteArray incoming = m_serial.readAll();
    if (incoming.isEmpty()) return;

    m_rxBuffer.append(incoming);

    while(m_rxBuffer.size() > 0) {
        if(m_rxBuffer.size() < 3) break;

        // Reset bufora przy dużych zakłóceniach
        if (m_rxBuffer.size() > 64) {
            logCom("<font color='orange'>Błąd rozmiaru: Reset bufora.</font>");
            m_rxBuffer.clear();
            m_waitingForResponse = false;
            break;
        }

        quint8 funcCode = (quint8)m_rxBuffer[1];

        // 0x06 Write Response (8 bajtów)
        if(funcCode == 0x06) {
            int expectedSize = 8;
            if(m_rxBuffer.size() >= expectedSize) {
                if(ui->textBrowser_5) ui->textBrowser_5->append("<font color='blue'>OK (0x06).</font>");
                m_rxBuffer.remove(0, expectedSize);
                continue;
            } else break;
        }

        // 0x03 Read Response (Nagłówek 3 + dane + 2 CRC)
        else if(funcCode == 0x03) {
            quint8 dataBytes = (quint8)m_rxBuffer[2];

            if (dataBytes > 40) {
                m_rxBuffer.remove(0, 1);
                continue;
            }

            int totalFrameSize = 3 + dataBytes + 2;

            if(m_rxBuffer.size() >= totalFrameSize) {
                QByteArray frame = m_rxBuffer.left(totalFrameSize);
                if(tryParseResponse(frame)) {
                    m_rxBuffer.remove(0, totalFrameSize);
                    m_waitingForResponse = false;
                } else {
                    m_rxBuffer.remove(0, 1);
                }
            } else break;
        }
        // Exception Modbus (Błąd zgłoszony przez falownik)
        else if(funcCode & 0x80) {
            if(m_rxBuffer.size() >= 5) {
                logCom(QString("<font color='red'>Błąd Modbus (Exception): %1</font>").arg((quint8)m_rxBuffer[2]));

                // WAŻNE: Jeśli czekaliśmy na manualne sprawdzenie, a przyszedł błąd - resetujemy flagę!
                if(m_manualCheckRequested) {
                    logCom("<b>(Żądanie manualne anulowane z powodu błędu Modbus)</b>");
                    m_manualCheckRequested = false;
                }

                m_rxBuffer.remove(0, 5);
                m_waitingForResponse = false;
            } else break;
        }
        else {
            m_rxBuffer.remove(0, 1);
        }
    }
}

bool MainWindow::tryParseResponse(QByteArray &frame) {
    if (frame.size() < 5) return false;
    if ((quint8)frame[1] != 0x03) return false;

    // --- DIAGNOSTYKA CRC ---
    QByteArray payload = frame.left(frame.size() - 2);
    quint16 calc = obliczNoweCRC(payload);
    quint16 rx = (quint8)frame[frame.size()-2] | ((quint8)frame[frame.size()-1] << 8);

    if(calc != rx) {
        logCom(QString("<font color='orange'>Błąd CRC! Ramka: %1 | Odebrano: %2 | Wyliczono: %3</font>")
                   .arg(QString(frame.toHex().toUpper()))
                   .arg(rx, 4, 16, QChar('0')).toUpper()
                   .arg(calc, 4, 16, QChar('0')).toUpper());
        return false;
    }

    // =================================================================
    // --- JEDNORAZOWY LOG MANUALNY (tylko po kliknięciu przycisku) ---
    // =================================================================
    if (m_manualCheckRequested) {
        m_manualCheckRequested = false; // Resetujemy flagę

        // Dekodowanie wartości surowych
        if (frame.size() >= 19) {
            quint16 rawErr      = ((quint8)frame[3] << 8) | (quint8)frame[4];
            quint16 rawStatus   = ((quint8)frame[5] << 8) | (quint8)frame[6];
            quint16 rawSetFreq  = ((quint8)frame[7] << 8) | (quint8)frame[8];
            quint16 rawOutFreq  = ((quint8)frame[9] << 8) | (quint8)frame[10];
            quint16 rawCurrent  = ((quint8)frame[11] << 8) | (quint8)frame[12];
            quint16 rawDC       = ((quint8)frame[13] << 8) | (quint8)frame[14];
            quint16 rawOutVolt  = ((quint8)frame[15] << 8) | (quint8)frame[16];

            // Budowanie raportu HTML
            QString log = "<br><b>Ramka: " + frame.toHex().toUpper() + "</b><br><br>";
            log += "<b>Nagłówek:</b><br>";
            log += QString("%1 -> Adres falownika (ID %2).<br>").arg(QString::number((quint8)frame[0], 16).toUpper().rightJustified(2,'0')).arg((quint8)frame[0]);
            log += QString("%1 -> Funkcja (Odczyt rejestrów).<br>").arg(QString::number((quint8)frame[1], 16).toUpper().rightJustified(2,'0'));
            log += QString("%1 -> Liczba bajtów danych: %2.<br>").arg(QString::number((quint8)frame[2], 16).toUpper().rightJustified(2,'0')).arg((quint8)frame[2]);

            log += "<br><b>Dane (Rejestry 2100H - 2106H):</b><br>";

            // 2100H Kod Błędu
            QString errDesc = (rawErr == 0) ? "BRAK BŁĘDÓW" : "BŁĄD!";
            log += QString("2100H (Kod Błędu): %1 -> %2.<br>")
                       .arg(rawErr, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(errDesc);

            // 2101H Status
            log += QString("2101H (Status): %1 -> Status pracy falownika.<br>")
                       .arg(rawStatus, 4, 16, QChar('0')).toUpper().insert(2, ' ');

            // 2102H Zadana Częstotliwość
            log += QString("2102H (Zadana Częstotliwość): %1 (Hex) = %2 (Dec) -> %3 Hz.<br>")
                       .arg(rawSetFreq, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(rawSetFreq)
                       .arg(rawSetFreq / 100.0, 0, 'f', 2);

            // 2103H Wyjściowa Częstotliwość
            log += QString("2103H (Wyjściowa Częstotliwość): %1 -> %2 Hz.<br>")
                       .arg(rawOutFreq, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(rawOutFreq / 100.0, 0, 'f', 2);

            // 2104H Prąd
            log += QString("2104H (Prąd Wyjściowy): %1 -> %2 A.<br>")
                       .arg(rawCurrent, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(rawCurrent / 100.0, 0, 'f', 2);

            // 2105H Napięcie DC
            log += QString("2105H (Napięcie szyny DC): %1 (Hex) = %2 (Dec) -> %3 V.<br>")
                       .arg(rawDC, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(rawDC)
                       .arg(rawDC / 10.0, 0, 'f', 1);

            // 2106H Napięcie Wyjściowe
            log += QString("2106H (Napięcie Wyjściowe): %1 -> %2 V.<br>")
                       .arg(rawOutVolt, 4, 16, QChar('0')).toUpper().insert(2, ' ')
                       .arg(rawOutVolt / 10.0, 0, 'f', 1);

            log += "<br><b>Suma Kontrolna CRC:</b><br>";
            log += QString("%1 -> Jest to poprawne CRC dla tej ramki.<br>")
                       .arg(rx, 4, 16, QChar('0')).toUpper().insert(2, ' ');

            logCom(log);
        }
    }

    // --- STANDARDOWE LOGI STATUSU (Monitoring ciągły - loguje tylko błędy) ---
    if (frame.size() >= 5) {
        quint16 errorCode = ((quint8)frame[3] << 8) | (quint8)frame[4];

        static int lastError = -1;
        if (errorCode != 0 && errorCode != lastError) {
            QString desc = "Nieznany";
            if(errorCode == 1) desc = "OC (Over Current)";
            else if(errorCode == 2) desc = "OV (Over Voltage)";
            else if(errorCode == 63) desc = "OT1 (Over Torque)";

            logCom(QString("<font color='red'><b>BŁĄD FALOWNIKA: %1 (Kod: %2)</b></font>")
                       .arg(desc).arg(errorCode));
            lastError = errorCode;
        } else if (errorCode == 0 && lastError != 0) {
            if(lastError != -1) logCom("<font color='green'>Status OK (Błąd usunięty).</font>");
            lastError = 0;
        }
    }

    // --- PARSOWANIE DANYCH DO WYKRESÓW ---
    double t = m_time.elapsed() / 1000.0;
    double current = 0.0, freq = 0.0, voltage = 0.0;
    bool hasData = false;

    if (frame.size() >= 11) {
        quint16 rawFreq = ((quint8)frame[9] << 8) | (quint8)frame[10];
        freq = rawFreq / 100.0;
    }

    if (frame.size() >= 13) {
        quint16 rawCurr = ((quint8)frame[11] << 8) | (quint8)frame[12];
        current = rawCurr / 100.0;
        hasData = true;
    }

    if (frame.size() >= 17) {
        quint16 rawVolt = ((quint8)frame[15] << 8) | (quint8)frame[16];
        voltage = rawVolt / 10.0;
    }

    if(m_measuring && hasData) {
        if(m_chartWindow && m_chartWindow->isVisible())
            m_chartWindow->appendDataPoint(t, current);
        if(m_chartWindow2 && m_chartWindow2->isVisible())
            m_chartWindow2->appendData(t, current, voltage, freq);
    }

    return true;
}

quint16 MainWindow::obliczNoweCRC(const QByteArray &data) {
    quint16 crc = 0xFFFF;

    for (int i = 0; i < data.size(); ++i) {
        crc ^= static_cast<quint8>(data.at(i));
        for (int j = 0; j < 8; ++j) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

void MainWindow::logCom(const QString &msg) {
    if(ui->textBrowser_5) ui->textBrowser_5->append(msg);
}

void MainWindow::onCrcCalcClicked() {}

void MainWindow::fillSerialUiDefaults() {
    ui->comboBox_2->clear();
    for (qint32 b : QSerialPortInfo::standardBaudRates())
        ui->comboBox_2->addItem(QString::number(b), b);

    // Domyślna prędkość: 115200
    ui->comboBox_2->setCurrentText("115200");

    ui->comboBox_3->clear(); ui->comboBox_3->addItem("8", QSerialPort::Data8);
    ui->comboBox_4->clear(); ui->comboBox_4->addItem("1", QSerialPort::OneStop); ui->comboBox_4->addItem("2", QSerialPort::TwoStop);
    ui->comboBox_5->clear(); ui->comboBox_5->addItem("None", QSerialPort::NoParity); ui->comboBox_5->addItem("Even", QSerialPort::EvenParity); ui->comboBox_5->addItem("Odd", QSerialPort::OddParity);
    ui->comboBox_6->clear(); ui->comboBox_6->addItem("None", QSerialPort::NoFlowControl);
}

bool MainWindow::applyUiSerialSettings(QString &humanDesc, QString &err) {
    QString portName = ui->comboBox->currentText().section(' ', 0, 0);
    if(portName.isEmpty()) { err = "Nie wybrano portu!"; return false; }

    m_serial.setPortName(portName);
    m_serial.setBaudRate(ui->comboBox_2->currentText().toInt());
    m_serial.setDataBits(static_cast<QSerialPort::DataBits>(ui->comboBox_3->currentData().toInt()));
    m_serial.setStopBits(static_cast<QSerialPort::StopBits>(ui->comboBox_4->currentData().toInt()));
    m_serial.setParity(static_cast<QSerialPort::Parity>(ui->comboBox_5->currentData().toInt()));
    m_serial.setFlowControl(static_cast<QSerialPort::FlowControl>(ui->comboBox_6->currentData().toInt()));

    humanDesc = QString("%1 @ %2").arg(portName).arg(m_serial.baudRate());
    return true;
}

void MainWindow::onRefreshPortsClicked() {
    ui->comboBox->clear();
    for(const auto &p : QSerialPortInfo::availablePorts())
        ui->comboBox->addItem(p.portName() + " " + p.description());
}

void MainWindow::onConnectClicked() {
    if(m_serial.isOpen()) return;
    QString human, err;
    if(!applyUiSerialSettings(human, err)) { logCom("Błąd: " + err); return; }
    m_rxBuffer.clear();
    if(m_serial.open(QIODevice::ReadWrite)) logCom("Połączono: " + human);
    else logCom("Błąd: " + m_serial.errorString());
}

void MainWindow::onDisconnectClicked() {
    m_pollTimer.stop();
    m_serial.close();
    logCom("Rozłączono.");
}

void MainWindow::onClearLogClicked() {
    if(ui->textBrowser_5) ui->textBrowser_5->clear();
}
