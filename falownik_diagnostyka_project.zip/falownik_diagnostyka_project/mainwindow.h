#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QTimer>
#include <QElapsedTimer>
#include <QByteArray>

class ChartWindow;
class chartwindow2;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onRefreshPortsClicked();
    void onConnectClicked();
    void onDisconnectClicked();
    void onClearLogClicked();

    // Zmieniona nazwa, aby uniknąć konfliktów z auto-connect
    void onManualStatusBtnClicked();
    void on_RESET_ERROR_STATUS_clicked();

    void onCrcCalcClicked();

    void updateFreqTarget(int value);
    void sendCmdFreq();
    void sendCmdStart();
    void sendCmdStop();

    void onOpenChartModuleClicked();
    void onOpenChartModule2Clicked();
    void onChartStartRequested();
    void onChartStopRequested();
    void onChartWindowClosed();

    void onPollTimeout();
    void onSerialReadyRead();

private:
    Ui::MainWindow *ui;
    QSerialPort m_serial;
    QTimer m_pollTimer;
    QByteArray m_rxBuffer;
    QElapsedTimer m_time;

    quint16 m_targetFreqRaw = 0;
    bool m_measuring = false;
    bool m_waitingForResponse = false;

    ChartWindow *m_chartWindow = nullptr;
    chartwindow2 *m_chartWindow2 = nullptr;

    void fillSerialUiDefaults();
    bool applyUiSerialSettings(QString &humanDesc, QString &err);
    void logCom(const QString &msg);

    void sendWriteRequest(quint16 address, quint16 value);
    void sendReadStatusAndDataRequest();
    bool tryParseResponse(QByteArray &frame);
    quint16 obliczNoweCRC(const QByteArray &data);

    // Flaga do obsługi ręcznego sprawdzania
    bool m_manualCheckRequested = false;
};

#endif // MAINWINDOW_H
